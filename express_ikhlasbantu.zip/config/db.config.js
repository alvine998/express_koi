module.exports = {
    url:"mongodb+srv://semesta21:1234@cluster0.dmyey.mongodb.net/ikhlasbantu?retryWrites=true&w=majority"
}